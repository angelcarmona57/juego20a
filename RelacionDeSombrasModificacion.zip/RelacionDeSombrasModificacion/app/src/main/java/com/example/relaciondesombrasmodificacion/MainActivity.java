package com.example.relaciondesombrasmodificacion;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView image1, image2, image3, image4, imageMain;
    TextView tv_status;
    Button b_next, b_play_again, b_exit_game;
    Integer[] images ={
            R.drawable.cuadrado,
            R.drawable.circulo,
            R.drawable.rectangulo,
            R.drawable.triangulo,
            R.drawable.hexagono,
            R.drawable.rombo,
            R.drawable.ovalo,
    };

    Integer[] images_bw ={
            R.drawable.cuadrado_punteado,
            R.drawable.circulo_punteado,
            R.drawable.rectangulo_punteado,
            R.drawable.triangulo_punteado,
            R.drawable.hexagono_punteado,
            R.drawable.rombo_punteado,
            R.drawable.ovalo_punteada,
    };

    Integer[] images_numbers = {0,1,2,3,4,5,6};
    int turn = 1;
    int correctAnswer = 0;
    int score = 0;
    private Handler handler = new Handler();
    private Notification.Builder iv_correct;
    private Notification.Builder iv_incorrect;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        image4 = findViewById(R.id.image4);
        imageMain = findViewById(R.id.imageMain);

        tv_status = findViewById(R.id.tv_status);

        b_next = findViewById(R.id.b_next);
        b_play_again = findViewById(R.id.b_play_again);
        b_exit_game = findViewById(R.id.b_exit_game);

        Collections.shuffle(Arrays.asList(images_numbers));

        setImages();

        image1.setOnClickListener(imageClickListener);
        image2.setOnClickListener(imageClickListener);
        image3.setOnClickListener(imageClickListener);
        image4.setOnClickListener(imageClickListener);

        b_play_again.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                turn = 1;
                score = 0;
                setImages();
                enableImages();
                b_next.setVisibility(View.INVISIBLE);
            }
        });

        b_exit_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setImages() {
        Random r = new Random();
        correctAnswer = r.nextInt(4) + 1;
        int wrongAnswer1, wrongAnswer2, wrongAnswer3;

        do {
            wrongAnswer1 = r.nextInt(7);
        } while (wrongAnswer1 == images_numbers[turn]);

        do {
            wrongAnswer2 = r.nextInt(7);
        } while (wrongAnswer2 == images_numbers[turn] || wrongAnswer2 == wrongAnswer1);

        do {
            wrongAnswer3 = r.nextInt(7);
        } while (wrongAnswer3 == images_numbers[turn] || wrongAnswer3 == wrongAnswer2 || wrongAnswer3 == wrongAnswer1);

        switch (correctAnswer) {
            case 1:
                image1.setImageResource(images[images_numbers[turn]]);
                image2.setImageResource(images[wrongAnswer1]);
                image3.setImageResource(images[wrongAnswer2]);
                image4.setImageResource(images[wrongAnswer3]);
                break;
            case 2:
                image1.setImageResource(images[wrongAnswer1]);
                image2.setImageResource(images[images_numbers[turn]]);
                image3.setImageResource(images[wrongAnswer2]);
                image4.setImageResource(images[wrongAnswer3]);
                break;
            case 3:
                image1.setImageResource(images[wrongAnswer1]);
                image2.setImageResource(images[wrongAnswer2]);
                image3.setImageResource(images[images_numbers[turn]]);
                image4.setImageResource(images[wrongAnswer3]);
                break;
            case 4:
                image1.setImageResource(images[wrongAnswer1]);
                image2.setImageResource(images[wrongAnswer2]);
                image3.setImageResource(images[wrongAnswer3]);
                image4.setImageResource(images[images_numbers[turn]]);
                break;
        }

        imageMain.setImageResource(images_bw[images_numbers[turn]]);
        tv_status.setText("");
        b_next.setVisibility(View.INVISIBLE);

        enableImages();
    }

    private void enableImages() {
        image1.setEnabled(true);
        image2.setEnabled(true);
        image3.setEnabled(true);
        image4.setEnabled(true);
    }

    private void disableImages() {
        image1.setEnabled(false);
        image2.setEnabled(false);
        image3.setEnabled(false);
        image4.setEnabled(false);
    }

    private void checkEnd() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setMessage("¡Juego terminado! Puntuación: " + score);

        alertDialogBuilder.setPositiveButton("Volver a Jugar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                turn = 1;
                score = 0;
                setImages();
                enableImages();
                b_next.setVisibility(View.INVISIBLE);
            }
        });

        alertDialogBuilder.setNegativeButton("Salir del Juego", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private View.OnClickListener imageClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int selectedAnswer = 0;
            switch (view.getId()) {
                case R.id.image1:
                    selectedAnswer = 1;
                    break;
                case R.id.image2:
                    selectedAnswer = 2;
                    break;
                case R.id.image3:
                    selectedAnswer = 3;
                    break;
                case R.id.image4:
                    selectedAnswer = 4;
                    break;
            }
            checkAnswer(selectedAnswer);
        }
    };
//Codigo del GIF
private void checkAnswer(int selectedAnswer) {
    if (selectedAnswer == correctAnswer) {
        score++;
        tv_status.setText("");
        showGif(R.raw.yes);
    } else {
        tv_status.setText("");
        showGif(R.raw.no);
    }
    disableImages();
    handler.postDelayed(new Runnable() {
        @Override
        public void run() {
            hideGif(); // Oculta el GIF después de un retraso
            nextQuestion();
        }
    }, 900); // 2 segundos de retraso antes de cambiar la pregunta
}

    private void showGif(int gifResource) {
        ImageView gifImageView = findViewById(R.id.gifImageView);
        gifImageView.setVisibility(View.VISIBLE);

        Glide.with(this)
                .asGif()
                .load(gifResource)
                .into(new SimpleTarget<GifDrawable>() {
                    @Override
                    public void onResourceReady(GifDrawable resource, Transition<? super GifDrawable> transition) {
                        resource.setLoopCount(GifDrawable.LOOP_FOREVER);
                        gifImageView.setImageDrawable(resource);
                        resource.start();
                    }
                });
    }

    private void hideGif() {
        ImageView gifImageView = findViewById(R.id.gifImageView);
        gifImageView.setVisibility(View.INVISIBLE);
        gifImageView.setImageDrawable(null); // Limpia el ImageView
    }



//Fin del Codigo del GIF
    private void nextQuestion() {
        turn++;
        if (turn == 7) {
            checkEnd();
        } else {
            setImages();
        }
    }
}
