package com.example.figurasconsusilueta;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    private ImageView imageView1;
    private ImageView imageView2;
    private Rect rect1 = new Rect();
    private Rect rect2 = new Rect();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);

        imageView1.post(() -> imageView1.getGlobalVisibleRect(rect1));
        imageView2.post(() -> imageView2.getGlobalVisibleRect(rect2));

        ObjectAnimator animator = ObjectAnimator.ofFloat(imageView1, View.TRANSLATION_X, 0f, 500f);
        animator.setDuration(5000); // Duración de la animación en milisegundos
        animator.setInterpolator(new LinearInterpolator());

        animator.addUpdateListener(animation -> {
            imageView1.getGlobalVisibleRect(rect1);
            if (rect1.intersect(rect2)) {
                // Colisión detectada, detén la animación y combina las imágenes.
                animator.cancel();
                imageView1.setVisibility(View.INVISIBLE);
            }
        });

        animator.start();
    }
}
