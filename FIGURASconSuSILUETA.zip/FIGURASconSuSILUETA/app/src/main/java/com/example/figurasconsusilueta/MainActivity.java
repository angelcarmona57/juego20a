package com.example.figurasconsusilueta;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private ImageView image1, image2, image3, image4;
    private float xDelta1, yDelta1, xDelta2, yDelta2, xDelta3, yDelta3, xDelta4, yDelta4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        image4 = findViewById(R.id.image4);

        setTouchListener(image1);
        setTouchListener(image2);
        setTouchListener(image3);
        setTouchListener(image4);
    }

    private void setTouchListener(final ImageView imageView) {
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                final float x = event.getRawX();
                final float y = event.getRawY();

                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:
                        if (imageView == image1) {
                            xDelta1 = x - view.getX();
                            yDelta1 = y - view.getY();
                        } else if (imageView == image2) {
                            xDelta2 = x - view.getX();
                            yDelta2 = y - view.getY();
                        } else if (imageView == image3) {
                            xDelta3 = x - view.getX();
                            yDelta3 = y - view.getY();
                        } else if (imageView == image4) {
                            xDelta4 = x - view.getX();
                            yDelta4 = y - view.getY();
                        }
                        break;
                    case MotionEvent.ACTION_MOVE:
                        if (imageView == image1) {
                            view.setX(x - xDelta1);
                            view.setY(y - yDelta1);
                        } else if (imageView == image2) {
                            view.setX(x - xDelta2);
                            view.setY(y - yDelta2);
                        } else if (imageView == image3) {
                            view.setX(x - xDelta3);
                            view.setY(y - yDelta3);
                        } else if (imageView == image4) {
                            view.setX(x - xDelta4);
                            view.setY(y - yDelta4);
                        }
                        break;
                }

                return true;
            }
        });
    }
}

